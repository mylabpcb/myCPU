# For use with logisim to load contents into memory
customasm -f logisim8
