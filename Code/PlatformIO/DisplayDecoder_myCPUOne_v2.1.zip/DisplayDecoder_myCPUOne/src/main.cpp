 /**
 * Decoder program for 7 segment 4 digits decimal display for Platform IO.
 * Version 2.1
 * 
 * This sketch is based on the program write by Ben Eater to program the EEProm memory
 * with the decoding values needed for the 7 segment display of the output module of his 
 * 8-bit Breadboard Computer design.
 * 
 * I've made some minor changes to support the AT28C64 EEProm memory instead of the AT28C16
 *  and my EEProm programmer module.
 * 
 * References to the original author, Ben Eater:  ben@eater.net
 * Channel: https://www.youtube.com/channel/UCS0N5baNlQWJCUrhCEo8WlA
 * Web: https://eater.net/
 * The decimal display decoder is described in https://youtu.be/dLh1n2dErzE
 */
 #include <Arduino.h>

#define SHIFT_DATA 4
#define SHIFT_CLK 2
#define SHIFT_LATCH 3
#define EEPROM_D0 5
#define EEPROM_D7 12
#define WRITE_EN 13

/* Used to show status information about running cycle */
#define FINISHED_LED A5
#define RUNNING_LED A4


/*
* Send the address and outputEnable signal through 4094 shift registers.
*/
void setAddress(int address, bool outputEnable) {
  shiftOut(SHIFT_DATA, SHIFT_CLK, MSBFIRST, (address >> 8) | (outputEnable ? 0x00 : 0x80));
  shiftOut(SHIFT_DATA, SHIFT_CLK, MSBFIRST, address);

  digitalWrite(SHIFT_LATCH, LOW);
  digitalWrite(SHIFT_LATCH, HIGH);
  digitalWrite(SHIFT_LATCH, LOW);
}

/*
* Set the pin mode of data pins.
*/
void setDataPinMode(boolean mode){
  for (int pin = EEPROM_D0; pin <= EEPROM_D7; pin += 1) {
    pinMode(pin, mode);
  }
}

/*
   Read a byte from memory at the specified address.
*/
byte readEEPROM(int address) {
  setDataPinMode(INPUT);
  setAddress(address, /*outputEnable*/ true);

  byte data = 0;
  for (int pin = EEPROM_D7; pin >= EEPROM_D0; pin -= 1) {
    data = (data << 1) + digitalRead(pin);
  }
  return data;
}


/*
   Write a byte to memory at the specified address.
*/
void writeEEPROM(int address, byte data) {
  setDataPinMode(OUTPUT);
  setAddress(address, /*outputEnable*/ false);
  for (int pin = EEPROM_D0; pin <= EEPROM_D7; pin += 1) {
    pinMode(pin, OUTPUT);
  }

  for (int pin = EEPROM_D0; pin <= EEPROM_D7; pin += 1) {
    digitalWrite(pin, data & 1);
    data = data >> 1;
  }
  digitalWrite(WRITE_EN, LOW);
  delayMicroseconds(1);
  digitalWrite(WRITE_EN, HIGH);
  delay(10);
}


/*
   Read the contents of the EEPROM and print them to the serial monitor.
*/
void printContents() {
  for (int base = 0; base <= 255; base += 16) {
    byte data[16];
    for (int offset = 0; offset <= 15; offset += 1) {
      data[offset] = readEEPROM(base + offset);
    }

    char buf[80];
    sprintf(buf, "%03x:  %02x %02x %02x %02x %02x %02x %02x %02x   %02x %02x %02x %02x %02x %02x %02x %02x",
            base, data[0], data[1], data[2], data[3], data[4], data[5], data[6], data[7],
            data[8], data[9], data[10], data[11], data[12], data[13], data[14], data[15]);

    Serial.println(buf);
  }
}


void setup() {
  // Configure LED indicators
  pinMode(FINISHED_LED, OUTPUT);
  pinMode(RUNNING_LED, OUTPUT);
  digitalWrite(RUNNING_LED, LOW);
  digitalWrite(FINISHED_LED, LOW);
  
  // Configure Shift Registers
  pinMode(SHIFT_DATA, OUTPUT);
  pinMode(SHIFT_CLK, OUTPUT);
  pinMode(SHIFT_LATCH, OUTPUT);
  

  // Initialize 
  pinMode(WRITE_EN, OUTPUT);
  digitalWrite(WRITE_EN, HIGH);
  
  // Configure monitor
  Serial.begin(57600);

  // Set bit patterns for the digits 0..9
  byte digits[] = { 0x7e, 0x30, 0x6d, 0x79, 0x33, 0x5b, 0x5f, 0x70, 0x7f, 0x7b };

  // Start writing
  digitalWrite(RUNNING_LED, HIGH);
  Serial.println("Programming ones place");
  for (int value = 0; value <= 255; value += 1) {
    writeEEPROM(value, digits[value % 10]);
  }
  Serial.println("Programming tens place");
  for (int value = 0; value <= 255; value += 1) {
    writeEEPROM(value + 256, digits[(value / 10) % 10]);
  }
  Serial.println("Programming hundreds place");
  for (int value = 0; value <= 255; value += 1) {
    writeEEPROM(value + 512, digits[(value / 100) % 10]);
  }
  Serial.println("Programming sign");
  for (int value = 0; value <= 255; value += 1) {
    writeEEPROM(value + 768, 0);
  }

  // Start writing "two complements"
  Serial.println("Programming ones place (twos complement)");
  for (int value = -128; value <= 127; value += 1) {
    writeEEPROM((byte)value + 1024, digits[abs(value) % 10]);
  }
  Serial.println("Programming tens place (twos complement)");
  for (int value = -128; value <= 127; value += 1) {
    writeEEPROM((byte)value + 1280, digits[abs(value / 10) % 10]);
  }
  Serial.println("Programming hundreds place (twos complement)");
  for (int value = -128; value <= 127; value += 1) {
    writeEEPROM((byte)value + 1536, digits[abs(value / 100) % 10]);
  }
  Serial.println("Programming sign (twos complement)");
  for (int value = -128; value <= 127; value += 1) {
    if (value < 0) {
      writeEEPROM((byte)value + 1792, 0x01);
    } else {
      writeEEPROM((byte)value + 1792, 0);
    }
  }
  
  // Read and print out the contents of the EERPROM
  Serial.println("Reading EEPROM");
  printContents();

  // Finished
  digitalWrite(RUNNING_LED, LOW);
  digitalWrite(FINISHED_LED, HIGH);
  
   //
  Serial.end();
}



void loop() {
  // put your main code here, to run repeatedly:

}