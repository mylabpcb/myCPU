#include <limits.h>
#include <stdint.h>

/*
 * Get a specific number of bits "n" starting at "offset" from "source"
 * This function was modified to support 32 bits unsigned size numbers.
*/
uint32_t getbits(uint32_t source, uint32_t offset, uint32_t n)
{
  const unsigned max_n = CHAR_BIT * sizeof(uint32_t);
  if (offset >= max_n)
    return 0; /* value is padded with infinite zeros on the left */
  source >>= offset; /* drop offset bits */
  if (n >= max_n)
    return source; /* all  bits requested */
  const unsigned mask = (1u << n) - 1; /* n '1's */
  return source & mask;
}