#ifndef getBits_H_
#define getBits_H_
uint32_t getbits(uint32_t source, uint32_t offset, uint32_t n);

#endif