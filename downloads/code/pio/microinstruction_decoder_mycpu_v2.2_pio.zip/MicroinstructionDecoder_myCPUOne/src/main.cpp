
/*
 * Microinstructions decoder program for Platform IO 
 * Version 2.2
 *
 * This program is based on the code written by Ben Eater to program the instruction decoder
 * of his 8-bit Breadboard Computer design.
 * 
 * I've made several modifications of the original code to support the length of the myCPU 
 * microinstruction word up to 22 bits.
 * Other changes are related to support the AT28C64 EEProm memory, to support my own design 
 * of the EEProm programmer module for that type of memory, and to bypassing the SRAM limit 
 * of arduino nano boards.
 * 
 * References to the original author, Ben Eater:  ben@eater.net
 * Channel: https://www.youtube.com/channel/UCS0N5baNlQWJCUrhCEo8WlA
 * Web: https://eater.net/
 * The instruction decoder programming is described in https://youtu.be/BA12Z7gQ4P0
 * */

#include <Arduino.h>
#include <Functions.h>


 // Shift register ports
#define SHIFT_DATA 4
#define SHIFT_CLK 2
#define SHIFT_LATCH 3

// EEProm ports: Supported 8 bits of data on pins from 5 to 12

#define EEPROM_D0 5
#define EEPROM_D7 12
#define WRITE_EN 13

// Used to show status information about running cycle on the EEProm programmer.
#define FINISHED_LED A5
#define RUNNING_LED A4

/*
 * We have defined binary constant values for each microinstruction control signal. Which has
 * a real length of 22 bits but we use 32 bits length to store in a uint32_t type array later 
 * in the microinstruction template.
 * 
 * Later it could be combined using OR function to create the entire microinstruction binary 
 * 32 bits word for each step of the instruction cycle.
 * Each part of the microinstruction word will be stored in a different EEProm memory at same address 
 * using the selection memory combination address bits A9-A10.
 * (we use 3 memories because we have a 22 (32) bits length control microinstruction) 
 * 
 */ 

/* PART A */
#define MI  0b00000000000000000000000000000100  // (MI) Memory address register IN
#define SI  0b00000000000000000000000000001000  // Stack Pointer register IN
#define SO  0b00000000000000000000000000010000  // Stack Pointer register OUT
#define RI  0b00000000000000000000000000100000  // RAM data IN
#define RO  0b00000000000000000000000001000000  // RAM data OUT
#define OI  0b00000000000000000000000010000000  // OUTPUT register IN

/* PART B */
#define UN  0b00000000000000000000000100000000  // Unsigned/signed signal for display (active LOW)
#define PE  0b00000000000000000000001000000000  // Program counter INCREMENT
#define PO  0b00000000000000000000010000000000  // Program counter OUT
#define J   0b00000000000000000000100000000000  // Program counter IN, PI control signal named as J(JMP) for better understanding
#define FI  0b00000000000000000001000000000000  // Flags register IN
#define II  0b00000000000000000010000000000000  // Instruction register IN
#define IO  0b00000000000000000100000000000000  // Instruction register OUT
#define CI  0b00000000000000001000000000000000  // C register IN

/* PART C */
#define CO  0b00000000000000010000000000000000  // C register OUT
#define BI  0b00000000000000100000000000000000  // B register IN
#define BO  0b00000000000001000000000000000000  // B register OUT
#define AI  0b00000000000010000000000000000000  // Accumulator register IN
#define AO  0b00000000000100000000000000000000  // Accumulator register OUT
#define SU  0b00000000001000000000000000000000  // Substract Enable/Disable (active HIGH)
#define EO  0b00000000010000000000000000000000  // ALU OUT
#define HLT 0b00000000100000000000000000000000  // HLT

/* 
 *  Here we have defined an array to hold four blocks of the microinstructions template referenced
 *  by the first dimension of the array. 
 *  We need 4 blocks because to cover conditional jumps intructions we need one block for each 
 *  combination of the state flags FV and FZ.
 *
 *  Due to, in this version of the microinstruction decoder, we use 4 bits for the Opcode 
 *  and 4 bits for an argument, We have 0-15 possible opcodes or instructions, 
 *  so we need to reserve 16 elements for each copy of the template, as the second dimension. 
 *  
 *  We support up to eight steps for the instruction execution cycle so we need eight items
 *  for each instrucion element.
 *  
 *  Because of using it as global variable exceed the capacity of SRAM memory of arduino Nano reserved for data,
 *  we are using a constant template instead.
*/

/*
 * Here define the array which contains the microinstructions for each Instruction Opcode.
 * FlagCombination refers to address bits A7,A8
 */

const uint32_t ucode[4][16][8] PROGMEM = {
  {
        // FlagCombination 0b00: FV, FZ = 0 NO JMP
        { MI | PO,  RO | II | PE,                                          0, 0, 0, 0, 0, 0 },      // 0000 - NOP
        { MI | PO,  RO | II | PE,  IO | MI,  RO | AI,                            0, 0, 0, 0 },      // 0001 - LDA
        { MI | PO,  RO | II | PE,  IO | MI,  RO | BI,  EO | AI | FI,                0, 0, 0 },      // 0010 - ADD
        { MI | PO,  RO | II | PE,  IO | MI,  RO | BI,  EO | AI | SU | FI,           0, 0, 0 },      // 0011 - SUB
        { MI | PO,  RO | II | PE,  IO | MI,  AO | RI,                            0, 0, 0, 0 },      // 0100 - STA
        { MI | PO,  RO | II | PE,  IO | AI,                                   0, 0, 0, 0, 0 },      // 0101 - LDI
        { MI | PO,  RO | II | PE,  IO | J,                                    0, 0, 0, 0, 0 },      // 0110 - JMP
        { MI | PO,  RO | II | PE,                                          0, 0, 0, 0, 0, 0 },      // 0111 - JV
        { MI | PO,  RO | II | PE,                                          0, 0, 0, 0, 0, 0 },      // 1000 - JZ
        { MI | PO,  RO | II | PE,  IO | MI,  RO | BI,                            0, 0, 0, 0 },      // 1001 - LDB
        { MI | PO,  RO | II | PE,  BO | AI,                                   0, 0, 0, 0, 0 },      // 1010 - MOVBA
        { MI | PO,  RO | II | PE,  IO | BI, EO | AI | FI,                        0, 0, 0, 0 },      // 1011 - INC
        { MI | PO,  RO | II | PE,  IO | BI, EO | AI | SU | FI,                   0, 0, 0, 0 },      // 1100 - DEC
        { MI | PO,  RO | II | PE,                                          0, 0, 0, 0, 0, 0 },      // 1101
        { MI | PO,  RO | II | PE,  AO | OI,                                   0, 0, 0, 0, 0 },      // 1110 - OUT
        { MI | PO,  RO | II | PE,  HLT,                                       0, 0, 0, 0, 0 }       // 1111 - HLT
  },
  {
        // FlagCombination 0b01: FV = 1, FZ = 0 JMP on FV
        { MI | PO,  RO | II | PE,                                          0, 0, 0, 0, 0, 0 },      // 0000 - NOP
        { MI | PO,  RO | II | PE,  IO | MI,  RO | AI,                            0, 0, 0, 0 },      // 0001 - LDA
        { MI | PO,  RO | II | PE,  IO | MI,  RO | BI,  EO | AI | FI,                0, 0, 0 },      // 0010 - ADD
        { MI | PO,  RO | II | PE,  IO | MI,  RO | BI,  EO | AI | SU | FI,           0, 0, 0 },      // 0011 - SUB
        { MI | PO,  RO | II | PE,  IO | MI,  AO | RI,                            0, 0, 0, 0 },      // 0100 - STA
        { MI | PO,  RO | II | PE,  IO | AI,                                   0, 0, 0, 0, 0 },      // 0101 - LDI
        { MI | PO,  RO | II | PE,  IO | J,                                    0, 0, 0, 0, 0 },      // 0110 - JMP
        { MI | PO,  RO | II | PE,  IO | J,                                    0, 0, 0, 0, 0 },      // 0111 - JV
        { MI | PO,  RO | II | PE,                                          0, 0, 0, 0, 0, 0 },      // 1000 - JZ
        { MI | PO,  RO | II | PE,  IO | MI,  RO | BI,                            0, 0, 0, 0 },      // 1001 - LDB
        { MI | PO,  RO | II | PE,  BO | AI,                                   0, 0, 0, 0, 0 },      // 1010 - MOVBA
        { MI | PO,  RO | II | PE,  IO | BI, EO | AI | FI,                        0, 0, 0, 0 },      // 1011 - INC
        { MI | PO,  RO | II | PE,  IO | BI, EO | AI | SU | FI,                   0, 0, 0, 0 },      // 1100 - DEC
        { MI | PO,  RO | II | PE,                                          0, 0, 0, 0, 0, 0 },      // 1101
        { MI | PO,  RO | II | PE,  AO | OI,                                   0, 0, 0, 0, 0 },      // 1110 - OUT
        { MI | PO,  RO | II | PE,  HLT,                                       0, 0, 0, 0, 0 }       // 1111 - HLT
  },
  {
        // FlagCombination 0b01: FV = 0, FZ = 1 JMP on FZ
        { MI | PO,  RO | II | PE,                                          0, 0, 0, 0, 0, 0 },      // 0000 - NOP
        { MI | PO,  RO | II | PE,  IO | MI,  RO | AI,                            0, 0, 0, 0 },      // 0001 - LDA
        { MI | PO,  RO | II | PE,  IO | MI,  RO | BI,  EO | AI | FI,                0, 0, 0 },      // 0010 - ADD
        { MI | PO,  RO | II | PE,  IO | MI,  RO | BI,  EO | AI | SU | FI,           0, 0, 0 },      // 0011 - SUB
        { MI | PO,  RO | II | PE,  IO | MI,  AO | RI,                            0, 0, 0, 0 },      // 0100 - STA
        { MI | PO,  RO | II | PE,  IO | AI,                                   0, 0, 0, 0, 0 },      // 0101 - LDI
        { MI | PO,  RO | II | PE,  IO | J,                                    0, 0, 0, 0, 0 },      // 0110 - JMP
        { MI | PO,  RO | II | PE,                                          0, 0, 0, 0, 0, 0 },      // 0111 - JV
        { MI | PO,  RO | II | PE,  IO | J,                                    0, 0, 0, 0, 0 },      // 1000 - JZ
        { MI | PO,  RO | II | PE,  IO | MI,  RO | BI,                            0, 0, 0, 0 },      // 1001 - LDB
        { MI | PO,  RO | II | PE,  BO | AI,                                   0, 0, 0, 0, 0 },      // 1010 - MOVBA
        { MI | PO,  RO | II | PE,  IO | BI, EO | AI | FI,                        0, 0, 0, 0 },      // 1011 - INC
        { MI | PO,  RO | II | PE,  IO | BI, EO | AI | SU | FI,                   0, 0, 0, 0 },      // 1100 - DEC
        { MI | PO,  RO | II | PE,                                          0, 0, 0, 0, 0, 0 },      // 1101
        { MI | PO,  RO | II | PE,  AO | OI,                                   0, 0, 0, 0, 0 },      // 1110 - OUT
        { MI | PO,  RO | II | PE,  HLT,                                       0, 0, 0, 0, 0 }       // 1111 - HLT
  },
  {
        // FlagCombination 0b11: FV, FZ = 1 JMP on FV and FZ
        { MI | PO,  RO | II | PE,                                          0, 0, 0, 0, 0, 0 },      // 0000 - NOP
        { MI | PO,  RO | II | PE,  IO | MI,  RO | AI,                            0, 0, 0, 0 },      // 0001 - LDA
        { MI | PO,  RO | II | PE,  IO | MI,  RO | BI,  EO | AI | FI,                0, 0, 0 },      // 0010 - ADD
        { MI | PO,  RO | II | PE,  IO | MI,  RO | BI,  EO | AI | SU | FI,           0, 0, 0 },      // 0011 - SUB
        { MI | PO,  RO | II | PE,  IO | MI,  AO | RI,                            0, 0, 0, 0 },      // 0100 - STA
        { MI | PO,  RO | II | PE,  IO | AI,                                   0, 0, 0, 0, 0 },      // 0101 - LDI
        { MI | PO,  RO | II | PE,  IO | J,                                    0, 0, 0, 0, 0 },      // 0110 - JMP
        { MI | PO,  RO | II | PE,  IO | J,                                    0, 0, 0, 0, 0 },      // 0111 - JV
        { MI | PO,  RO | II | PE,  IO | J,                                    0, 0, 0, 0, 0 },      // 1000 - JZ
        { MI | PO,  RO | II | PE,  IO | MI,  RO | BI,                            0, 0, 0, 0 },      // 1001 - LDB
        { MI | PO,  RO | II | PE,  BO | AI,                                   0, 0, 0, 0, 0 },      // 1010 - MBA
        { MI | PO,  RO | II | PE,  IO | BI, EO | AI | FI,                        0, 0, 0, 0 },      // 1011 - INC
        { MI | PO,  RO | II | PE,  IO | BI, EO | AI | SU | FI,                   0, 0, 0, 0 },      // 1100 - DEC
        { MI | PO,  RO | II | PE,                                          0, 0, 0, 0, 0, 0 },      // 1101
        { MI | PO,  RO | II | PE,  AO | OI,                                   0, 0, 0, 0, 0 },      // 1110 - OUT
        { MI | PO,  RO | II | PE,  HLT,                                       0, 0, 0, 0, 0 }       // 1111 - HLT
  }
};

/*
 * Send the address bits and outputEnable signal to shift registers which hold those values
 * to write o read operations with the memory.
 * 
 * First shift the data to the input registers and then send signal to store the values to 
 * the storage registers.
 * 
 */
void setAddress(int address, bool outputEnable) {
  shiftOut(SHIFT_DATA, SHIFT_CLK, MSBFIRST, (address >> 8) | (outputEnable ? 0x00 : 0x80));
  shiftOut(SHIFT_DATA, SHIFT_CLK, MSBFIRST, address);

  digitalWrite(SHIFT_LATCH, LOW);
  digitalWrite(SHIFT_LATCH, HIGH);
  digitalWrite(SHIFT_LATCH, LOW);
}

/*
 * Set the pim mode for the defined data pins.
 */
void setDataPinMode(boolean mode){
  for (int pin = EEPROM_D0; pin <= EEPROM_D7; pin += 1) {
    pinMode(pin, mode);
  }
}

/*
 * Read a byte from the EEPROM at the specified address.
 */
byte readEEPROM(int address) {
  setDataPinMode(INPUT);
  setAddress(address, /*outputEnable*/ true);
  //
  byte data = 0;
  for (int pin = EEPROM_D7; pin >= EEPROM_D0; pin -= 1) {
    data = (data << 1) + digitalRead(pin);
  }
  return data;
}

/*
 * Write a byte to the EEPROM at the specified address.
 * Write bits from less significative to most significative according to the wiring order of
 * between arduino pins and memory inputs.
 */
void writeEEPROM(int address, byte data) {
  setDataPinMode(OUTPUT);
  setAddress(address, /*outputEnable*/ false);
 
  for (int pin = EEPROM_D0; pin <= EEPROM_D7; pin += 1) {
    digitalWrite(pin, data & 1);
    data = data >> 1;
  }
  digitalWrite(WRITE_EN, LOW);
  delayMicroseconds(1);
  digitalWrite(WRITE_EN, HIGH);
  delay(10);
}

/*
 * Read the contents of the EEPROM and print them to the serial monitor.
 */
void printContents(int start, int length) {
  for (int base = start; base < length; base += 16) {
    byte data[16];
    for (int offset = 0; offset <= 15; offset += 1) {
      data[offset] = readEEPROM(base + offset);
    }

    char buf[80];
    sprintf(buf, "%03x:  %02x %02x %02x %02x %02x %02x %02x %02x   %02x %02x %02x %02x %02x %02x %02x %02x",
            base, data[0], data[1], data[2], data[3], data[4], data[5], data[6], data[7],
            data[8], data[9], data[10], data[11], data[12], data[13], data[14], data[15]);

    Serial.println(buf);
  }
}


void setup() {
  // Configure LED indicators
  pinMode(FINISHED_LED, OUTPUT);
  pinMode(RUNNING_LED, OUTPUT);
  digitalWrite(RUNNING_LED, LOW);
  digitalWrite(FINISHED_LED, LOW);

  // Configure Shift Register
  pinMode(SHIFT_DATA, OUTPUT);
  pinMode(SHIFT_CLK, OUTPUT);
  pinMode(SHIFT_LATCH, OUTPUT);
  
  // Configure writing
  pinMode(WRITE_EN, OUTPUT);
  digitalWrite(WRITE_EN, HIGH);

  // Confgure monitor
  Serial.begin(57600);
  
  // Begin programming memory
  Serial.print("Programming EEPROM");
  digitalWrite(RUNNING_LED, HIGH);

  /*
   * We support in this version a 2^11 bits length address which include the memory selector bits
   * A9,A10, so we need to iterate up to 2048 maximum address value.
  */
  
  for (int address = 0; address < 2048; address += 1) {

    //  Address length take 11 bits,: 
    //  3 for steps: A0,A1,A2, 
    //  4 for instruction opcode: A3,A4,A5,A6, 
    //  2 for flags combination: A7,A8,
    //  2 for memory selection: A9,A10 
    
    /* 
     *  Using bitwise to get an integer from specific portions of a byte 
     *  to get the step, opcode, flags combination and selection memory values on the current iteration.
     */

    // A0,A1,A2 are to step count, comes from flag register/step counter module
    int steps = (address & 0b00000000111);
    
    // A3,A4,A5,A6 are to instruction Opcode, comes from instruction register module
    int Opcode = (address & 0b00001111000) >> 3;
    
    // A7,A8, are to flags register, comes from flag register/step counter module
    int flags  = (address & 0b00110000000) >> 7; 
    
    // A9,A10 is fixed on the pcb adn the combinations are (01)-MEM1,(10)-MEM2,(11)-MEM3
    int memory   =  (address & 0b11000000000) >> 9;
   
    /* 
     *  Because writeEEProm function takes a byte of data to write, we use a function (getbits) to isolate
     *  the byte part and moving forward over the 32 bits of the microinstruction word.
     */
    switch(memory){
      // Value 0 MEM0 not exist in this release
      case 0:
        //Write 0 to block corresponding to MEM0 because there's no MEM0 memory, memories start at "01" value of selection memory.
        writeEEPROM(address, 0);
        break;
      // Value 1 select MEM1 and write less significative 8 bits of microinstruction
      case 1:
        writeEEPROM(address, getbits(pgm_read_dword_near(&ucode[flags][Opcode][steps]), 0, 8));
        break;
      // Value 2 select MEM2 and write middle significative 8 bits of microinstruction, bitwise left 8 bits
      case 2:
        writeEEPROM(address, getbits(pgm_read_dword_near(&ucode[flags][Opcode][steps]), 8, 8));
        break;
      // Value 3 select MEM3 and write most significative 8 bits of microinstruction, bitwise left 16 bits
      case 3:
        writeEEPROM(address, getbits(pgm_read_dword_near(&ucode[flags][Opcode][steps]), 16, 8));
        break;
      default:
        break;
    }
    // Show writing progress indicator
    if (address % 64 == 0) {
      Serial.print(".");
    }
  }


  Serial.println(" done");
  // Finished, change EEProm programmer indicators.
  digitalWrite(RUNNING_LED, LOW);
  digitalWrite(FINISHED_LED, HIGH);
  
  // Read and print out the contents of the EERPROM
  Serial.println("Reading EEPROM");
  printContents(0, 2048);
}


void loop() {

}